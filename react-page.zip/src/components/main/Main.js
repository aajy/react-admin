function Main() {
  return (
    <div>
      메인화면
    </div>
  )
}

export default Main
