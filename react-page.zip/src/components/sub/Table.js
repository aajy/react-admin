function Table() {
  return (
    <div>
      
    </div>
  )
}

export default Table
